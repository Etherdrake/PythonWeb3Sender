import os

import numpy
import websocket, json, time
from sortedcontainers import SortedDict
from decimal import Decimal

from dotenv import load_dotenv
import pandas as pd
import numpy as np
import talib

from pprint import pprint

from web3 import Web3

# dYdX dependencies
from dydx3 import Client
from dydx3.constants import *

load_dotenv()

dydx_mainnet = 'https://api.dydx.exchange'
dydx_staging = 'https://api.stage.dydx.exchange'

dydx_wss_staging = "wss://api.stage.dydx.exchange/v3/ws"

web3 = Web3(Web3.HTTPProvider(API_HOST_ROPSTEN))

ETH_ADDRESS = os.getenv('ETH_ADDRESS')
ETH_PRIVATE_KEY = os.getenv('ETH_PRIVATE_KEY')
API_KEY = os.getenv('API_KEY')
API_PASSPHRASE = os.getenv('API_PASSPHRASE')
API_SECRET = os.getenv('API_SECRET')
STARK_PUBLIC_KEY = os.getenv('STARK_PUBLIC_KEY')
STARK_PUBLIC_KEY_Y_COORDINATE = os.getenv('STARK_PUBLIC_KEY_Y_COORDINATE')
STARK_PRIVATE_KEY = os.getenv('STARK_PRIVATE_KEY')
POSITION_ID = os.getenv('POSITION_ID')

# Ropsten Init
client = Client(
    host=API_HOST_ROPSTEN,
    stark_private_key=STARK_PRIVATE_KEY,
    eth_private_key=ETH_PRIVATE_KEY,
    network_id=NETWORK_ID_ROPSTEN,
)

"""
Channels are:

v3_accounts
v3_orderbook
v3_trades
v3_markets

"""
account_response = client.private.get_account(ethereum_address=ETH_ADDRESS)
position_id = account_response.data['account']['positionId']

security_name = "BTC-USD"
size = 0.50
pct_spread = 0.2

rsi_list = []
fast_rsi_list = []

rsi_value_list = []
time_tuple = ()
counter = 0
mem = -1
last_price = 0
sell_mode = False
fast_mode = False



def run_script():
    def on_open(ws):
        print("opened")
        channel_data = {"type": "subscribe", "channel": "v3_markets", "id": "BTC-USD", "includeOffsets": "True"}
        ws.send(json.dumps(channel_data))

    def on_message(ws, message):
        global counter
        global rsi_list
        global fast_rsi_list
        global rsi_value_list
        global time_tuple
        global mem
        global last_price
        global position_id
        global sell_mode
        global fast_mode

        message_obj = json.loads(message)

        print(message)
        print("[ ======================= ]")
        print(f"Sell mode is: {sell_mode}")
        print(f"Fast mode is: {fast_mode}")
        print(f"Counter is: {counter}")
        print(f"Last Price: {last_price}")
        print(f"RSI Values: {rsi_list}")
        print(f"Current RSI values in memory: {rsi_value_list}")
        print(f"Memory time: {mem}")

        if message_obj['type'] == 'channel_data':
            now = int(time.time())
            print(f"Current Time: {now}")
            if now == mem:
                if 'BTC-USD' in message_obj['contents']:
                    last_price = target_btc(message_obj)

                    # If the list of values is empty, get the first value,
                    # reset the counter and start counting
                    if len(rsi_list) == 0:
                        index_price = target_btc(message_obj)
                        rsi_list.append(index_price)
                        counter = 0

                    elif len(rsi_list) < 14 and counter % 60 == 0:
                        index_price = target_btc(message_obj)
                        rsi_list.append(index_price)

                    elif len(rsi_list) == 14 and counter % 60 == 0:
                        index_price = target_btc(message_obj)
                        rsi_list.pop(0)
                        rsi_list.append(index_price)
                else:
                    if len(rsi_list) < 14 and counter % 60 == 0:
                        rsi_list.append(last_price)

                    elif len(rsi_list) == 14 and counter % 60 == 0:
                        rsi_list.pop(0)
                        rsi_list.append(last_price)

            # Adjust for latency and time-variance
            if mem == -1 or now == mem:
                mem = now + 5
                counter += 5
            elif now - mem >= 10 and mem > 0:
                counter += ((now - mem) // 5 * 5)
                mem = now + 5
            elif now == mem + 1:
                mem -= 1
                counter += 5

            if len(rsi_list) == 14 and counter % 60 == 0:
                latest_rsi = get_rsi(rsi_list)
                rsi_value_list.insert(0, [latest_rsi, now])
                print(f"Latest 1M RSI: {latest_rsi}")
                if latest_rsi < 30 and not sell_mode:
                    price_string_int = int(rsi_list[-1] + 30)
                    price_string = str(price_string_int)
                    # Create order parameters.
                    order_params = {
                        'position_id': position_id,
                        'market': MARKET_BTC_USD,
                        'side': ORDER_SIDE_BUY,
                        'order_type': ORDER_TYPE_MARKET,
                        'post_only': False,
                        'size': '0.50',
                        'price': price_string,
                        'limit_fee': '0.015',
                        'expiration_epoch_seconds': time.time() + 120,
                        'time_in_force': TIME_IN_FORCE_FOK
                    }
                    try:
                        place_order(order_params)
                        # Pop the first 4 values so the algorithm will wait approx. 4 minutes
                        del rsi_list[:4]
                        sell_mode = 0
                        # Set sell_mode to True
                        sell_mode = True
                    except Exception as e:
                        print(e)

                elif latest_rsi > 70 and sell_mode:
                    print(f"Sell signal has appeared on 1M time-frame: {latest_rsi}")
                    price_string_int = int(rsi_list[-1] - 30)
                    price_string = str(price_string_int)
                    order_params = {
                        'position_id': position_id,
                        'market': MARKET_BTC_USD,
                        'side': ORDER_SIDE_SELL,
                        'order_type': ORDER_TYPE_MARKET,
                        'post_only': False,
                        'size': '0.50',
                        'price': price_string,
                        'limit_fee': '0.015',
                        'expiration_epoch_seconds': time.time() + 120,
                        'time_in_force': TIME_IN_FORCE_FOK
                    }
                    try:
                        place_order(order_params)
                        del rsi_list[:4]
                        sell_mode = False
                    except Exception as e:
                        print(e)

            print("[ ======================= ]")
            # if len(rsi_list) == 14:
            #     df = pd.DataFrame({'close': rsi_list})

    def on_close(ws):
        print("[---] CONNECTION CLOSED [---] ")

    def target_btc(message_obj):
        price = message_obj['contents']['BTC-USD']['indexPrice']
        price = float(price)
        return price

    def get_rsi(rsi_list):
        close = np.array(rsi_list)
        rsi = talib.RSI(close, timeperiod=13)
        return float(rsi[-1])

    def place_order(order_params):
        order_creation_response = client.private.create_order(**order_params)
        pprint(f"Order has been created \n")

    def cancel_all():
        client.private.cancel_all_orders()

    socket = dydx_wss_staging
    ws = websocket.WebSocketApp(socket, on_open=on_open, on_message=on_message, on_close=on_close)
    ws.run_forever()


run_script()
