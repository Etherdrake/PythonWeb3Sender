import os

import numpy
import websocket, json, time
from sortedcontainers import SortedDict
from decimal import Decimal

from dotenv import load_dotenv
import pandas as pd
import numpy as np
import talib

from pprint import pprint

from web3 import Web3

# dYdX dependencies
from dydx3 import Client
from dydx3.constants import *

load_dotenv()

web3 = Web3(Web3.HTTPProvider(API_HOST_ROPSTEN))

ETH_ADDRESS = os.getenv('ETH_ADDRESS')
ETH_PRIVATE_KEY = os.getenv('ETH_PRIVATE_KEY')
API_KEY = os.getenv('API_KEY')
API_PASSPHRASE = os.getenv('API_PASSPHRASE')
API_SECRET = os.getenv('API_SECRET')
STARK_PUBLIC_KEY = os.getenv('STARK_PUBLIC_KEY')
STARK_PUBLIC_KEY_Y_COORDINATE = os.getenv('STARK_PUBLIC_KEY_Y_COORDINATE')
STARK_PRIVATE_KEY = os.getenv('STARK_PRIVATE_KEY')
POSITION_ID = os.getenv('POSITION_ID')

# Ropsten Init
client = Client(
    host=API_HOST_ROPSTEN,
    stark_private_key=STARK_PRIVATE_KEY,
    eth_private_key=ETH_PRIVATE_KEY,
    network_id=NETWORK_ID_ROPSTEN,
)

security_name = "BTC-USD"
size = 0.50
pct_spread = 0.2

account_response = client.private.get_account(ethereum_address=ETH_ADDRESS)
position_id = account_response.data['account']['positionId']

# Post a market-order.
order_params = {
    'position_id': position_id,
    'market': MARKET_BTC_USD,
    'side': ORDER_SIDE_BUY,
    'order_type': ORDER_TYPE_MARKET,
    'post_only': False,
    'size': '0.50',
    'price': str(39900),
    'limit_fee': '0.015',
    'expiration_epoch_seconds': time.time() + 120,
    'time_in_force': TIME_IN_FORCE_FOK
}

order_creation_response = client.private.create_order(**order_params)
pprint(order_creation_response.data)
