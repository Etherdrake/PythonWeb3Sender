import json

f = open('data.json')

# returns JSON object as
# a dictionary
data = json.load(f)

# Iterating through the json
# list

index_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]


price = data['contents']['BTC-USD']['indexPrice']
price = float(price)

print(len(index_list))
